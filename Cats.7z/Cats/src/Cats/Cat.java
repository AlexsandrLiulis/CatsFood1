package Cats;

public class Cat {
    public static int count = 0;
    public static double plat = 10;
    public static double bowl = 20;

    private int name;

    public Cat() {
        count++;
    }

    public void setName(int name) {
        this.name = name;
    }

    public int getName() {
        return name;
    }
}
