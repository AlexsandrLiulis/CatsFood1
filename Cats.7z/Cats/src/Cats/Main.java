package Cats;

public class Main {
    public static void main(String[] args) {
        int CatSize = 10;

        Cat[] cats = new Cat[CatSize];
        for (int i = 0; i <cats.length; i++) {
            cats[i] = new Cat();
            cats[i].setName(i + 1);
        }
        System.out.println("Колличество кошек " + Cat.count);
        System.out.println("Колличество молока " + Cat.plat + " литров");
        System.out.println("Колличество корма " + Cat.bowl + " кг\n");

        double catsMilk = Cat.plat / CatSize;
        double catsFood = Cat.bowl / CatSize;

        for (int i = 0; i < cats.length; i++) {
            System.out.println(cats[i].getName() + " кошка пьёт молоко");
            Cat.plat -= catsMilk;
            if (Cat.plat > 0){
                System.out.println("Осталось " + Cat.plat + " л. молока");
            }else {
                System.out.println("Больше молока нет");
            }
            System.out.println(" ");
        }

        for (int i = 0; i < cats.length; i++) {
            System.out.println(cats[i].getName() + " кошка ест корм");
            Cat.bowl -= catsFood;
            if (Cat.bowl > 0){
                System.out.println("Осталось " + Cat.bowl + " кг");
            }else {
                System.out.println("Больше корма нет");
            }
            System.out.println(" ");
        }
    }
}
